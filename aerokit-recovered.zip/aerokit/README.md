# AeroKit (recovered from single-file build)

This folder was recovered from `AeroKit.html`.

- `index.html` – entry page (open directly or serve statically)
- `assets/app.css`, `assets/redesign.css` – the two stylesheets from the HTML
- `assets/app.js` – the bundled, minified app (React + all tools)
- `original-source-v1/` – the readable TypeScript/React source from the earlier
  `aerokit.zip`. It predates the redesign and extra features in AeroKit.html
  (it can't be regenerated from the minified bundle).

Note: `index.html` loads `lamejs` and `mp4box` from the jsDelivr CDN, as the original did.
